const {
  shareAll,
  withModuleFederationPlugin,
} = require("@angular-architects/module-federation/webpack");

module.exports = withModuleFederationPlugin({
  name: "mf-user",

  exposes: {
    "./Component": "./src/app/app.component.ts",
    "./UserRoutes": "./src/app/app.routes.ts",
    "./UserRegistrationComponent":
      "./src/app/features/create/component/user-registration/user-registration.component.ts",
    "./ListComponent":
      "./src/app/features/list/component/list/list.component.ts",
  },

  shared: {
    ...shareAll({
      singleton: true,
      strictVersion: true,
      requiredVersion: "auto",
    }),
  },
});
