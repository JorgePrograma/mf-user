import { Injectable, signal } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { catchError, delay, map, tap } from 'rxjs/operators';
import { PositionModel } from '../../model/position.model';
import { POSTS_MOCK } from '../../mocks/postsMock';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { EndPoints } from '../../core/utils/endpoints';
import { Config } from '../../core/utils/config';

@Injectable({
  providedIn: 'root',
})
export class PositionService {
  // Signal para manejar el estado reactivo de los tipos de documentos
  private readonly _positions = signal<PositionModel[]>([]);
  positionSignal = this._positions.asReadonly();
  constructor(private readonly http: HttpClient) {}
  private readonly authToken = Config.TOKEN;

  /**
   * Obtiene todos los tipos de documentos.
   */

  getPosition(): Observable<PositionModel[]> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${this.authToken}`,
    });

    return this.http.get<any>(EndPoints.GET_ALL_POSITION, {headers}).pipe(
      map((response) => {
        try {
          console.log('response postion', response);
          return response ?? [];
        } catch (error) {
          console.error('Error parseando JSON:', error);
          return [];
        }
      }),
      tap(position =>{
        this._positions.set(position)
      }),
      catchError((error) => {
        console.error('Error en la solicitud HTTP:', error);
        return of([]);
      })
    );
  }
}
