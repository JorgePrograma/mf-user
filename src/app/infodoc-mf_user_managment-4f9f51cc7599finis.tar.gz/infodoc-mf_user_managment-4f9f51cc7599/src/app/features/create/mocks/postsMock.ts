import { PositionModel } from "../model/position.model";

export const POSTS_MOCK: PositionModel[] = [
 
];
