export interface ContactInfoModel{
  idPerson:string,
  email:string,
  phone:string,
  address:string
}
