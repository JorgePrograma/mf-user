import { CommonModule } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { BasicInfoModel } from './../../model/basic-info.model';
import { EmployeeInfoModel } from './../../model/employee-info.model';
import { NotificationService } from './../../services/notification/notification.service';

// Material
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatStepperModule } from '@angular/material/stepper';

// Componentes de Sección
import { AccountInfoComponent } from '../account-info/account-info.component';
import { BasicInfoComponent } from '../basic-info/basic-info.component';
import { EmployeeInfoComponent } from '../employee-info/employee-info.component';

// SweetAlert2
import {
  catchError,
  forkJoin,
  of,
  switchMap,
  tap,
  throwError
} from 'rxjs';
import { ContactInfoModel } from '../../model/contact-info.model';
import { ResponseModel } from '../../model/response.model';
import { UserService } from '../../services/user/user.service';
import { ContactInfoComponent } from '../contact-info/contact-info.component';

@Component({
  selector: 'app-user-registration',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatStepperModule,
    MatButtonModule,
    MatIconModule,
    BasicInfoComponent,
    EmployeeInfoComponent,
    AccountInfoComponent,
    ContactInfoComponent,
  ],
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.css'],
})
export class UserRegistrationComponent implements OnInit {
  private readonly fb = inject(FormBuilder);
  private readonly userService = inject(UserService);
  private readonly notificationService = inject(NotificationService);
  registrationForm!: FormGroup;
  isEditable = true;
  private generateRandomDocumentNumber(): string {
    // Genera un número aleatorio de 10 dígitos
    return Math.floor(1000000000 + Math.random() * 9000000000).toString();
  }

  ngOnInit(): void {
    this.registrationForm = this.fb.group({
      basicInfo: this.fb.group({
        documentType: ['CC', Validators.required],
        documentNumber: [
          this.generateRandomDocumentNumber(),
          [Validators.required, Validators.pattern(/^\d+$/)],
        ],
        firstName: ['jorge', Validators.required],
        middleName: [''],
        lastName: ['martelo', Validators.required],
        secondLastName: [''],
      }),
      contactInfo: this.fb.group({
        country: ['Colombia', Validators.required],
        city: ['Bogota', Validators.required],
        department: ['Bogota', Validators.required],
        address: ['mc - de e', [Validators.required]],
        email: ['test@gmail.com', [Validators.required, Validators.email]],
        phone: [
          '3123456789',
          [Validators.required, Validators.pattern(/^\d{10}$/)],
        ],
      }),
      employeeInfo: this.fb.group({
        bussinesEmail: [
          'test@gmail.com',
          [Validators.required, Validators.email],
        ],
        bussinesPhone: [
          '3121234567',
          [Validators.required, Validators.pattern(/^\d{10}$/)],
        ],
        idPosition: ['', Validators.required],
        idBranch: ['sucursal', Validators.required],
      }),
      accountInfo: this.fb.group(
        {
          avatar: ['CC', Validators.required],
          idRole: ['martelo', Validators.required],
          isDirectoryActive: [false, Validators.required],
          user: new FormControl({ value: '', disabled: true }, Validators.required),
          password: new FormControl(
            { value: '', disabled: true },
            [
              Validators.required,
              Validators.minLength(8),
              Validators.pattern(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/)
            ]
          ),
          confirmationPassword: new FormControl(
            { value: '', disabled: true },
            Validators.required
          )
        },
        { validator: this.passwordMatchValidator }
      )


    });
  }

  passwordMatchValidator(formGroup: FormGroup) {
    const password = formGroup.get('password')?.value;
    const confirmation = formGroup.get('confirmationPassword')?.value;
    return password === confirmation ? null : { passwordMismatch: true };
  }
  getFormGroup(groupName: string): FormGroup {
    return this.registrationForm.get(groupName) as FormGroup;
  }
  onSubmit(): void {
    const { basicInfo, contactInfo, employeeInfo, accountInfo } =
      this.registrationForm.value;

    // 1. Modelos de datos
    const basicInfoModel: BasicInfoModel = {
      documentType: basicInfo.documentType,
      documentNumber: basicInfo.documentNumber,
      firstName: basicInfo.firstName,
      middleName: basicInfo.middleName ?? undefined,
      lastName: basicInfo.lastName,
      secondLastName: basicInfo.secondLastName ?? undefined,
    };

    const contactInfoModel: ContactInfoModel = {
      idPerson: '', // Se asigna después
      email: contactInfo.email, // correo no se puede duplicar
      phone: contactInfo.phone,
      address: contactInfo.address,
    };

    const employeeInfoModel: EmployeeInfoModel = {
      bussinesEmail: employeeInfo.bussinesEmail,
      bussinesPhone: employeeInfo.bussinesPhone,
      idPerson: '', // Se asigna después
    };

    this.userService
      .getUserByDocument(basicInfoModel.documentNumber)
      .pipe(
        switchMap((user) => {
          if (user) {
            this.notificationService.showError(
              'Ya existe un usuario con ese documento'
            );
            return throwError(() => 'Usuario ya existe');
          }
          return this.userService.registerBasicInfo(basicInfoModel);
        }),
        switchMap((basicInfoResponse: ResponseModel<string>) => {
          const idPerson = basicInfoResponse.data;
          contactInfoModel.idPerson = idPerson;
          employeeInfoModel.idPerson = idPerson;

          // Ejecutar en paralelo la creación de contacto y empleado
          return forkJoin([
            this.userService.registerContactInfo(contactInfoModel),
            this.userService.registerEmployeeInfo(employeeInfoModel),
          ]);
        }),
        tap({
          next: ([contactResponse, employeeResponse]) => {
            // Mostrar en consola las respuestas
            console.log('Respuesta de Contacto:', contactResponse);
            console.log('Respuesta de Empleado:', employeeResponse);

            // Puedes mostrar mensajes personalizados según la respuesta
            if (contactResponse && employeeResponse) {
              this.notificationService.showSuccess(
                'Usuario registrado exitosamente'
              );
            } else {
              this.notificationService.showError(
                'Hubo un problema al registrar el usuario.'
              );
            }
          },
          error: (error) => {
            // Este error solo se ejecuta si ocurre en el tap, no en el flujo anterior
            this.notificationService.showError(
              'Error al registrar el usuario: ' + error
            );
            console.error('Error:', error);
          },
        }),
        catchError((error) => {
          // Manejo de errores centralizado
          if (error !== 'Usuario ya existe') {
            this.notificationService.showError(
              'Error al conectar con el servidor: ' + error
            );
            console.error('Error:', error);
          }
          return of(null); // Evita que el observable se rompa
        })
      )
      .subscribe();
  }

  // Helper para ver errores (opcional, para depuración)
  getFormErrors(form: AbstractControl): any {
    if (!form) {
      return null;
    }

    const result: any = {};

    if (form.errors) {
      result['_self'] = form.errors;
    }

    if ((form as FormGroup).controls) {
      for (const key in (form as FormGroup).controls) {
        const controlErrors = this.getFormErrors((form as FormGroup).get(key)!);
        if (controlErrors) {
          result[key] = controlErrors;
        }
      }
    }

    return result;
  }
}
