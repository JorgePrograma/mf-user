export interface BasicInfoModel {
  id?: string;
  documentType: string;
  documentNumber: string;
  firstName: string;
  middleName?: string;
  lastName: string;
  secondLastName?: string;
}
