import { HttpInterceptorFn } from '@angular/common/http';
import { Config } from './utils/config';

export const AuthInterceptor: HttpInterceptorFn = (req, next) => {
  const token = localStorage.getItem('auth_token');
  if (token) {
    const authReq = req.clone({
      setHeaders: {
        Authorization: `Bearer ${Config.TOKEN}`
      }
    });
    return next(authReq);
  }
  return next(req);
};
