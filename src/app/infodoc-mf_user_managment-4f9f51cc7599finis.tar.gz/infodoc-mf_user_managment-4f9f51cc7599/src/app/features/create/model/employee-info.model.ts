export interface EmployeeInfoModel {
  idPerson: string;
  bussinesEmail: string;
  bussinesPhone?: string;
  idPosition?: string;
  idBranch?: string;
}
