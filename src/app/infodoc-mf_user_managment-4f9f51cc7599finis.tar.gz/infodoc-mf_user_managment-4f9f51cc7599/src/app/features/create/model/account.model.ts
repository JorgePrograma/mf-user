export interface AccountModel{
  id:string
  logo?:string,
  password:string,
  role:string,
}