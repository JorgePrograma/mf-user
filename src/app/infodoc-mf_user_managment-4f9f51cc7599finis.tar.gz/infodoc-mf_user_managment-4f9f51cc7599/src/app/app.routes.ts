import { Routes } from '@angular/router';
import { UserRegistrationComponent } from './features/create/component/user-registration/user-registration.component';
import { ListComponent } from './features/list/component/list/list.component';

export const USER_ROUTES: Routes = [
  {
    path: '', // Ruta relativa (el prefijo 'user' lo define el host)
    component: UserRegistrationComponent, // Componente contenedor principal
    children: [
      {
        path: 'create',
        component: UserRegistrationComponent // O crea un componente específico
      },
      {
        path: 'list',
        component: ListComponent
      },
      { path: '', redirectTo: 'create', pathMatch: 'full' }
    ]
  }
];
